Isaac Kim
ikim26
G01201648
Lecture: 003